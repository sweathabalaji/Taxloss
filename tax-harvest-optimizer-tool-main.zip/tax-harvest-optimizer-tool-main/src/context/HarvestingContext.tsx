
import React, { createContext, useState, useContext, useEffect, ReactNode } from 'react';
import { Holding, CapitalGains, SelectedHoldings } from '../types';
import { fetchHoldings, fetchCapitalGains } from '../services/api';
import { toast } from '@/hooks/use-toast';

interface HarvestingContextProps {
  holdings: Holding[];
  originalCapitalGains: CapitalGains;
  afterHarvestingGains: CapitalGains;
  selectedHoldings: SelectedHoldings;
  savings: number;
  isLoading: boolean;
  error: string | null;
  toggleHoldingSelection: (coin: string) => void;
  toggleAllHoldings: (selected: boolean) => void;
  isAllSelected: boolean;
}

const HarvestingContext = createContext<HarvestingContextProps | undefined>(undefined);

export const useHarvesting = () => {
  const context = useContext(HarvestingContext);
  if (!context) {
    throw new Error('useHarvesting must be used within a HarvestingProvider');
  }
  return context;
};

interface HarvestingProviderProps {
  children: ReactNode;
}

export const HarvestingProvider: React.FC<HarvestingProviderProps> = ({ children }) => {
  const [holdings, setHoldings] = useState<Holding[]>([]);
  const [originalCapitalGains, setOriginalCapitalGains] = useState<CapitalGains>({
    stcg: { profits: 0, losses: 0 },
    ltcg: { profits: 0, losses: 0 }
  });
  const [afterHarvestingGains, setAfterHarvestingGains] = useState<CapitalGains>({
    stcg: { profits: 0, losses: 0 },
    ltcg: { profits: 0, losses: 0 }
  });
  const [selectedHoldings, setSelectedHoldings] = useState<SelectedHoldings>({});
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch data on component mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true);
        const [holdingsData, gainsData] = await Promise.all([
          fetchHoldings(),
          fetchCapitalGains()
        ]);

        // Sort holdings by total value (currentPrice * totalHolding) descending
        const sortedHoldings = [...holdingsData].sort((a, b) => 
          (b.currentPrice * b.totalHolding) - (a.currentPrice * a.totalHolding)
        );
        
        setHoldings(sortedHoldings);
        setOriginalCapitalGains(gainsData);
        setAfterHarvestingGains(gainsData);
        
        // Initialize selected holdings object
        const initialSelected = sortedHoldings.reduce((acc, holding) => {
          acc[holding.coin] = false;
          return acc;
        }, {} as SelectedHoldings);
        
        setSelectedHoldings(initialSelected);
        setIsLoading(false);
      } catch (err) {
        setError('Failed to fetch data. Please try again later.');
        setIsLoading(false);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to fetch data. Please try again later."
        });
      }
    };

    fetchData();
  }, []);

  // Calculate after harvesting gains based on selected holdings
  useEffect(() => {
    if (holdings.length === 0 || !originalCapitalGains) return;

    const calculateAfterHarvestingGains = () => {
      // Start with the original gains
      const newGains = { ...originalCapitalGains };

      // For each selected holding, update the profits/losses
      holdings.forEach(holding => {
        if (selectedHoldings[holding.coin]) {
          // Update short-term capital gains
          if (holding.stcg.gain > 0) {
            newGains.stcg.profits += holding.stcg.gain;
          } else if (holding.stcg.gain < 0) {
            newGains.stcg.losses += Math.abs(holding.stcg.gain);
          }

          // Update long-term capital gains
          if (holding.ltcg.gain > 0) {
            newGains.ltcg.profits += holding.ltcg.gain;
          } else if (holding.ltcg.gain < 0) {
            newGains.ltcg.losses += Math.abs(holding.ltcg.gain);
          }
        }
      });

      setAfterHarvestingGains(newGains);
    };

    calculateAfterHarvestingGains();
  }, [selectedHoldings, holdings, originalCapitalGains]);

  // Toggle a single holding selection
  const toggleHoldingSelection = (coin: string) => {
    setSelectedHoldings(prevState => ({
      ...prevState,
      [coin]: !prevState[coin]
    }));
  };

  // Toggle all holdings selection
  const toggleAllHoldings = (selected: boolean) => {
    const newSelectedState = { ...selectedHoldings };
    Object.keys(newSelectedState).forEach(coin => {
      newSelectedState[coin] = selected;
    });
    setSelectedHoldings(newSelectedState);
  };

  // Check if all holdings are selected
  const isAllSelected = holdings.length > 0 && 
    holdings.every(holding => selectedHoldings[holding.coin]);

  // Calculate savings (pre-harvesting realised gains - post-harvesting realised gains)
  const preHarvestingNet = 
    (originalCapitalGains.stcg.profits - originalCapitalGains.stcg.losses) + 
    (originalCapitalGains.ltcg.profits - originalCapitalGains.ltcg.losses);
  
  const postHarvestingNet = 
    (afterHarvestingGains.stcg.profits - afterHarvestingGains.stcg.losses) + 
    (afterHarvestingGains.ltcg.profits - afterHarvestingGains.ltcg.losses);
  
  const savings = preHarvestingNet > postHarvestingNet ? preHarvestingNet - postHarvestingNet : 0;

  const value = {
    holdings,
    originalCapitalGains,
    afterHarvestingGains,
    selectedHoldings,
    savings,
    isLoading,
    error,
    toggleHoldingSelection,
    toggleAllHoldings,
    isAllSelected
  };

  return (
    <HarvestingContext.Provider value={value}>
      {children}
    </HarvestingContext.Provider>
  );
};
