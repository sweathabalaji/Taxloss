
import { HarvestingProvider } from '@/context/HarvestingContext';
import Dashboard from '@/components/Dashboard';

const Index = () => {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <HarvestingProvider>
        <Dashboard />
      </HarvestingProvider>
    </div>
  );
};

export default Index;
