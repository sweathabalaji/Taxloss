
import { CapitalGains } from '@/types';

interface GainsCardProps {
  title: string;
  gains: CapitalGains;
  bgColor: string;
  savings?: number;
}

const GainsCard = ({ title, gains, bgColor, savings }: GainsCardProps) => {
  // Calculate net capital gains
  const netShortTermGains = gains.stcg.profits - gains.stcg.losses;
  const netLongTermGains = gains.ltcg.profits - gains.ltcg.losses;
  const totalRealizedGains = netShortTermGains + netLongTermGains;

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: 0
    }).format(value);
  };

  return (
    <div className={`${bgColor} rounded-lg p-5 md:p-6 shadow-lg relative overflow-hidden w-full`}>
      <h3 className="text-white font-semibold text-xl mb-4">{title}</h3>

      {/* Short-Term Capital Gains */}
      <div className="mb-6">
        <h4 className="text-dashboard-subtext font-medium mb-2">Short-Term</h4>
        <div className="grid grid-cols-2 gap-2 mb-2">
          <div>
            <p className="text-dashboard-subtext text-sm">Profits</p>
            <p className="text-dashboard-profit font-medium">{formatCurrency(gains.stcg.profits)}</p>
          </div>
          <div>
            <p className="text-dashboard-subtext text-sm">Losses</p>
            <p className="text-dashboard-loss font-medium">{formatCurrency(gains.stcg.losses)}</p>
          </div>
        </div>
        <div className="flex justify-between items-center">
          <p className="text-dashboard-subtext text-sm">Net</p>
          <p className={`font-medium ${netShortTermGains >= 0 ? 'text-dashboard-profit' : 'text-dashboard-loss'}`}>
            {formatCurrency(netShortTermGains)}
          </p>
        </div>
      </div>

      {/* Long-Term Capital Gains */}
      <div className="mb-6">
        <h4 className="text-dashboard-subtext font-medium mb-2">Long-Term</h4>
        <div className="grid grid-cols-2 gap-2 mb-2">
          <div>
            <p className="text-dashboard-subtext text-sm">Profits</p>
            <p className="text-dashboard-profit font-medium">{formatCurrency(gains.ltcg.profits)}</p>
          </div>
          <div>
            <p className="text-dashboard-subtext text-sm">Losses</p>
            <p className="text-dashboard-loss font-medium">{formatCurrency(gains.ltcg.losses)}</p>
          </div>
        </div>
        <div className="flex justify-between items-center">
          <p className="text-dashboard-subtext text-sm">Net</p>
          <p className={`font-medium ${netLongTermGains >= 0 ? 'text-dashboard-profit' : 'text-dashboard-loss'}`}>
            {formatCurrency(netLongTermGains)}
          </p>
        </div>
      </div>

      {/* Realized Capital Gains */}
      <div className="pt-4 border-t border-white/20">
        <div className="flex justify-between items-center">
          <p className="text-white font-medium">Realized Capital Gains</p>
          <p className={`font-semibold text-lg ${totalRealizedGains >= 0 ? 'text-dashboard-profit' : 'text-dashboard-loss'}`}>
            {formatCurrency(totalRealizedGains)}
          </p>
        </div>
      </div>

      {/* Savings Message */}
      {savings && savings > 0 && (
        <div className="mt-4 bg-dashboard-profit/10 p-3 rounded-md border border-dashboard-profit/30">
          <p className="text-dashboard-profit text-sm font-medium">
            You're going to save {formatCurrency(savings)}
          </p>
        </div>
      )}
    </div>
  );
};

export default GainsCard;
