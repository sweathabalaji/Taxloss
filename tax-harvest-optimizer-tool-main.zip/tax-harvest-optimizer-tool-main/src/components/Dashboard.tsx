
import { useHarvesting } from '@/context/HarvestingContext';
import GainsCard from './GainsCard';
import HoldingsTable from './HoldingsTable';
import Loader from './Loader';

const Dashboard = () => {
  const { 
    originalCapitalGains, 
    afterHarvestingGains, 
    savings,
    isLoading, 
    error 
  } = useHarvesting();

  if (error) {
    return (
      <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-md mt-8">
        <p className="font-bold">Error</p>
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl md:text-3xl font-bold mb-6">Tax Loss Harvesting Tool</h1>
      
      {isLoading ? (
        <Loader />
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <GainsCard 
              title="Pre-Harvesting" 
              gains={originalCapitalGains} 
              bgColor="bg-dashboard-dark"
            />
            <GainsCard 
              title="After Harvesting" 
              gains={afterHarvestingGains} 
              bgColor="bg-dashboard-blue"
              savings={savings}
            />
          </div>

          <div className="mt-8">
            <h2 className="text-xl font-semibold mb-4">Your Holdings</h2>
            <HoldingsTable />
          </div>
        </>
      )}
    </div>
  );
};

export default Dashboard;
