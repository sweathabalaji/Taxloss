
import { useState } from 'react';
import { useHarvesting } from '@/context/HarvestingContext';
import { Holding } from '@/types';
import { Checkbox } from '@/components/ui/checkbox';

const HoldingsTable = () => {
  const { 
    holdings, 
    selectedHoldings, 
    toggleHoldingSelection, 
    toggleAllHoldings, 
    isAllSelected 
  } = useHarvesting();
  
  const [showAll, setShowAll] = useState(false);
  const displayLimit = 5;

  const displayedHoldings = showAll ? holdings : holdings.slice(0, displayLimit);

  // Format currency
  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR',
      maximumFractionDigits: value < 0.01 ? 6 : value < 1 ? 4 : 2
    }).format(value);
  };

  // Format number for holdings
  const formatHolding = (value: number) => {
    if (value === 0) return '0';
    if (value < 0.00001) return value.toExponential(6);
    if (value < 0.001) return value.toFixed(6);
    if (value < 1) return value.toFixed(4);
    if (value > 10000) return new Intl.NumberFormat('en-IN').format(Math.floor(value));
    return new Intl.NumberFormat('en-IN').format(value);
  };

  return (
    <div className="mt-8 bg-white dark:bg-dashboard-dark rounded-lg shadow-lg overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full">
          <thead className="bg-gray-100 dark:bg-gray-800">
            <tr>
              <th className="px-4 py-3 text-left">
                <Checkbox 
                  checked={isAllSelected}
                  onCheckedChange={(checked) => toggleAllHoldings(!!checked)}
                />
              </th>
              <th className="px-4 py-3 text-left text-sm font-semibold">Asset</th>
              <th className="px-4 py-3 text-left text-sm font-semibold">
                <div>Holdings</div>
                <div className="text-xs font-normal text-gray-500">Avg Buy Price</div>
              </th>
              <th className="px-4 py-3 text-right text-sm font-semibold">Current Price</th>
              <th className="px-4 py-3 text-right text-sm font-semibold">
                <div>Short-Term Gain</div>
                <div className="text-xs font-normal text-gray-500">Balance</div>
              </th>
              <th className="px-4 py-3 text-right text-sm font-semibold">
                <div>Long-Term Gain</div>
                <div className="text-xs font-normal text-gray-500">Balance</div>
              </th>
              <th className="px-4 py-3 text-right text-sm font-semibold">Amount to Sell</th>
            </tr>
          </thead>
          <tbody>
            {displayedHoldings.map((holding) => (
              <tr 
                key={holding.coin}
                className={`border-t border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors ${
                  selectedHoldings[holding.coin] ? 'bg-blue-50 dark:bg-blue-800/10' : ''
                }`}
              >
                <td className="px-4 py-3">
                  <Checkbox 
                    checked={selectedHoldings[holding.coin] || false}
                    onCheckedChange={() => toggleHoldingSelection(holding.coin)}
                  />
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <img 
                      src={holding.logo} 
                      alt={holding.coin} 
                      className="w-6 h-6 rounded-full"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = "https://koinx-statics.s3.ap-south-1.amazonaws.com/currencies/DefaultCoin.svg";
                      }} 
                    />
                    <div>
                      <p className="font-medium">{holding.coin}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{holding.coinName}</p>
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3">
                  <p>{formatHolding(holding.totalHolding)}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {formatCurrency(holding.averageBuyPrice)}
                  </p>
                </td>
                <td className="px-4 py-3 text-right">
                  {formatCurrency(holding.currentPrice)}
                </td>
                <td className="px-4 py-3 text-right">
                  <p className={holding.stcg.gain >= 0 ? 'text-dashboard-profit' : 'text-dashboard-loss'}>
                    {formatCurrency(holding.stcg.gain)}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {formatHolding(holding.stcg.balance)}
                  </p>
                </td>
                <td className="px-4 py-3 text-right">
                  <p className={holding.ltcg.gain >= 0 ? 'text-dashboard-profit' : 'text-dashboard-loss'}>
                    {formatCurrency(holding.ltcg.gain)}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {formatHolding(holding.ltcg.balance)}
                  </p>
                </td>
                <td className="px-4 py-3 text-right">
                  {selectedHoldings[holding.coin] ? formatHolding(holding.totalHolding) : '-'}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      
      {holdings.length > displayLimit && (
        <div className="py-3 px-4 bg-gray-50 dark:bg-gray-800/50 border-t border-gray-200 dark:border-gray-700">
          <button
            onClick={() => setShowAll(!showAll)}
            className="text-blue-600 dark:text-blue-400 hover:underline text-sm font-medium"
          >
            {showAll ? 'View Less' : `View All (${holdings.length - displayLimit} more)`}
          </button>
        </div>
      )}
    </div>
  );
};

export default HoldingsTable;
